package com.scan;

public class Multi {
    private int a;
    private int b;

    public Multi(int a, int b){
        this.a = a;
        this.b = b;
    }

    public void multi(){
        System.out.println("Ответ: " + (this.a * this.b));
    }

}
